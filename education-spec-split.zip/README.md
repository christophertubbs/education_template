# Education specification split

Start with deliverable/README_SPEC_SPLIT.md.

- deliverable/: reviewable repository overlay with root SPEC, stage specifications, common handoff, retained runtime requirements, mapping fixtures and agent documentation.
- work/: original source snapshots, work log, decision summaries, intermediate draft checkpoint, reproduction utilities and validation results. These are evidence, not application files.
- SHA256.json: hashes of archived file bytes.

No GitHub writes or application changes were performed. The Markdown reader and integration gaps are documented future application work.
